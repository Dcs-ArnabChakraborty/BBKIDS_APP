import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  FlatList,
  ActivityIndicator,
  StyleSheet,
  Pressable,
  Dimensions
} from 'react-native';
import { router } from 'expo-router';
import { GetFilteredSectionDetails } from '@/utils/api';
import { useLocalSearchParams } from 'expo-router';

interface CategoryItem {
  unique_id: string;
  name: string;
  des: string | null;
  mrp: number;
  img: string;
}

export default function SectionScreen() {
  const params = useLocalSearchParams();
  const name = params?.name as string;
  const decodedName = decodeURIComponent(name);

  const [sectionItems, setSectionItems] = useState<CategoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchSectionItems = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const filterCriteria = {
          category: name,
        };

        const response = await GetFilteredSectionDetails(filterCriteria);
        if (response.data) {
          setSectionItems(response.data);
        } else {
          throw new Error('No data received from API');
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch items');
      } finally {
        setIsLoading(false);
      }
    };

    if (name) {
      fetchSectionItems();
    }
  }, [name]);

  const renderItem = ({ item }: { item: CategoryItem }) => (
    <Pressable
      style={styles.itemContainer}
      onPress={() => router.push({
        pathname: '/item/[id]',
        params: { id: item.unique_id }
      })}
    >
      <View style={styles.card}>
        <Image
          source={{ uri: item.img || 'https://via.placeholder.com/400x300' }}
          style={styles.image}
          resizeMode="cover"
        />
        <View style={styles.cardContent}>
          <Text style={styles.itemName}>{item.name}</Text>
          <Text style={styles.description}>
            {item.des || 'No description available'}
          </Text>
          <Text style={styles.price}>Rs.{item.mrp}</Text>
        </View>
      </View>
    </Pressable>
  );

  if (isLoading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }

  if (!sectionItems || sectionItems.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>{decodedName}</Text>
        <Text style={styles.noItemsText}>No items found in this category</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{decodedName}</Text>
      <FlatList
        data={sectionItems}
        renderItem={renderItem}
        keyExtractor={(item) => item.unique_id}
        numColumns={2}
        contentContainerStyle={styles.listContent}
        columnWrapperStyle={styles.columnWrapper}
      />
    </View>
  );
}

const { width } = Dimensions.get('window');
const CARD_WIDTH = (width - 36) / 2;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#1a1a1a',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 20,
    textAlign: 'center',
  },
  listContent: {
    paddingBottom: 16,
  },
  columnWrapper: {
    justifyContent: 'space-between',
  },
  itemContainer: {
    width: CARD_WIDTH,
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#1F2937',
    borderRadius: 8,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  image: {
    width: '100%',
    height: 150,
  },
  cardContent: {
    padding: 12,
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    color: 'white',
    marginBottom: 4,
  },
  description: {
    fontSize: 12,
    color: '#9CA3AF',
    marginBottom: 4,
  },
  price: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#10B981',
  },
  errorText: {
    color: 'red',
    fontSize: 16,
    textAlign: 'center',
  },
  noItemsText: {
    color: '#6B7280',
    fontSize: 16,
    textAlign: 'center',
    marginTop: 20,
  },
});