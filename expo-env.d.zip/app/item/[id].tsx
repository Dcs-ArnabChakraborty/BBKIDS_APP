import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  ActivityIndicator,
  StyleSheet,
  ScrollView,
  Button,
  Alert
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';

interface ItemDetails {
  unique_id: string;
  name: string;
  des: string;
  mrp: number;
  img: string;
  // Add any additional fields you need
}

export default function ItemScreen() {
  const params = useLocalSearchParams();
  const id = params?.id as string;

  const [item, setItem] = useState<ItemDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Simulating data fetching for testing purposes
    setTimeout(() => {
      const mockData = {
        unique_id: '1',
        name: 'Sample Item',
        des: 'This is a sample description of the item.',
        mrp: 1000,
        img: 'https://via.placeholder.com/400x300',
      };

      setItem(mockData);
      setLoading(false);
    }, 2000);
  }, [id]);

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
        <Button title="Go Back" onPress={() => router.back()} />
      </View>
    );
  }

  if (!item) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Item not found</Text>
        <Button title="Go Back" onPress={() => router.back()} />
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        <Image
          source={{ uri: item.img }}
          style={styles.image}
          resizeMode="cover"
        />

        <View style={styles.detailsContainer}>
          <Text style={styles.title}>{item.name}</Text>
          <Text style={styles.description}>{item.des || 'No description available'}</Text>
          <Text style={styles.price}>Rs. {item.mrp}</Text>

          <Button
            title="Buy Now"
            onPress={() => Alert.alert('Purchase', 'Buy button clicked!')}
            color="#10B981"
          />
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
  },
  container: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    padding: 16,
  },
  image: {
    width: '100%',
    height: 300,
    borderRadius: 8,
    marginBottom: 20,
  },
  detailsContainer: {
    paddingHorizontal: 8,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 12,
  },
  description: {
    fontSize: 16,
    color: '#9CA3AF',
    marginBottom: 20,
    lineHeight: 24,
  },
  price: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#10B981',
    marginBottom: 30,
  },
  errorText: {
    color: 'red',
    fontSize: 18,
    marginBottom: 20,
    textAlign: 'center',
  },
});
